﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Exercise.Common
{
    public static class FileReader
    {
        public static string[] ReadTextFile(string filePath)
        {
            try
            {
                return File.ReadAllLines(filePath);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
