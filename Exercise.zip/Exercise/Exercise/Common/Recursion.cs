﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise.Common
{
    class Recursion
    {
        private int elementLevel = -1;
        private int numberOfElements;
        private int[] permutationValue = new int[0];

        public Dictionary<string, int> dic = new Dictionary<string, int>();

        private char[] inputSet;
        public char[] InputSet
        {
            get { return inputSet; }
            set { inputSet = value; }
        }

        private int permutationCount = 0;
        public int PermutationCount
        {
            get { return permutationCount; }
            set { permutationCount = value; }
        }

        public char[] MakeCharArray(string InputString)
        {
            char[] charString = InputString.ToCharArray();
            Array.Resize(ref permutationValue, charString.Length);
            numberOfElements = charString.Length;
            return charString;
        }

        public void CalcPermutation(int k)
        {
            elementLevel++;
            permutationValue.SetValue(elementLevel, k);

            if (elementLevel == numberOfElements)
            {

                string permut = OutputPermutation(permutationValue);
                if (!dic.ContainsKey(permut))
                {
                    dic.Add(permut, 0);
                }
            }
            else
            {
                for (int i = 0; i < numberOfElements; i++)
                {
                    if (permutationValue[i] == 0)
                    {
                        CalcPermutation(i);
                    }
                }
            }
            elementLevel--;
            permutationValue.SetValue(0, k);
        }

        private string OutputPermutation(int[] value)
        {
            string ans = String.Empty;
            foreach (int i in value)
            {
                ans += inputSet.GetValue(i - 1);
            }
            PermutationCount++;

            return ans;
        }
    }
}
