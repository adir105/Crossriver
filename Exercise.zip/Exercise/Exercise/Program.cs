﻿using Exercise.Common;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Exercise
{
    class Program
    {
        static void Main(string[] args)
        {
            const string filePath = @"C:\Users\user\Downloads\data.txt";
            Exercise1(filePath);

            Console.WriteLine();

            Exercise2();

            Console.ReadKey();
        }

        private static void Exercise1(string filePath)
        {

            // Declare a regx for alphanumerical of 5 characters.
            Regex r = new Regex(@"^([a-zA-Z0-9]+){5}$");
            string userInput = String.Empty;

            while (!r.IsMatch(userInput) || userInput.Length != 5)
            {
                Console.WriteLine("Input must contain only letters of 5 characters.");
                userInput = Console.ReadLine();
            }

            Console.WriteLine("User input Valid: " + userInput);

            //Step 1: Extract all file to list of dictionary
            List<Dictionary<char, int>> list = new List<Dictionary<char, int>>();
            string[] lines = FileReader.ReadTextFile(filePath);
            for (int i = 0; i < lines.Length; i++)
            {
                // Extract each line to charcter (key) and count (value) of him.
                Dictionary<char, int> dic = new Dictionary<char, int>();
                foreach (var ch in lines[i])
                {
                    if (dic.ContainsKey(ch))
                    {
                        dic[ch]++;
                    }
                    else
                    {
                        dic.Add(ch, 1);
                    }

                }
                list.Add(dic);
            }

            // Extract user input to dictionary.
            Dictionary<char, int> inputDic = new Dictionary<char, int>();
            foreach (var ch in userInput)
            {
                if (inputDic.ContainsKey(ch))
                {
                    inputDic[ch]++;
                }
                else
                {
                    inputDic.Add(ch, 1);
                }
            }

            // Step 2: Comparission
            Console.WriteLine();

            Stopwatch sw1 = new Stopwatch();
            sw1.Start();
            var result1 = isPermutatationUsingSort(userInput, lines);
            sw1.Stop();
            Console.WriteLine("Result of isPermutatationUsingSort()");
            Console.WriteLine(result1[0]);
            Console.WriteLine(result1[1]);
            Console.WriteLine("Time: " + sw1.Elapsed.TotalSeconds);

            Console.WriteLine();

            Stopwatch sw2 = new Stopwatch();
            sw2.Start();
            var result2 = isPermutatationUsingOneDictionary(userInput, lines);
            sw2.Stop();
            Console.WriteLine("Result of isPermutatationUsingOneDictionary()");
            Console.WriteLine(result2[0]);
            Console.WriteLine(result2[1]);
            Console.WriteLine("Time: " + sw2.Elapsed.TotalSeconds);
        }

        private static string[] isPermutatationUsingOneDictionary(string userInput, string[] lines)
        {
            string ans = "Line numbers: ";
            string linesAns = "Lines: ";
            int lineNumber = 0;
            Recursion rec = new Recursion();
            rec.InputSet = rec.MakeCharArray(userInput);
            rec.CalcPermutation(0);
            
            for (int i = 0; i < lines.Length; i++)
            {
                lineNumber++;
                if (rec.dic.ContainsKey(lines[i]))
                {
                    ans += lineNumber + " ";
                    linesAns += lines[i] + " ";
                }
            }
            return new string[] { ans, linesAns };
        }

        private static string[] isPermutatationUsingSort(string inputUser, string[] lines)
        {
            string ans = "Line numbers: ";
            string linesAns = "Lines: ";

            int lineNumber = 0;
            // Sort the input user string.
            char[] inputUserChars = inputUser.ToCharArray();
            Array.Sort(inputUserChars);

            foreach (var line in lines)
            {
                lineNumber++;
                if (inputUser.Length != line.Length)
                    break;

                char[] lineChars = line.ToCharArray();
                Array.Sort(lineChars);

                for (int i = 0; i < inputUserChars.Length; i++)
                {
                    if (inputUserChars[i] != lineChars[i])
                    {
                        break;
                    }
                    else if (i == inputUserChars.Length-1)
                    {
                        ans += lineNumber.ToString() + " ";
                        linesAns += line + " "; 
                    }
                }
            }
            return new string[] { ans, linesAns };
        }

        private static async void Exercise2()
        {
            int cashiersNumber = 5;
            int totalTasks = 0;
            List<Task> tasks = new List<Task>();

            // Start all tasks & and add then to tasks list.
            for (int i = 0; i < cashiersNumber; i++)
            {
                totalTasks += 1;
                Task task = Task.Run(taskToDo);
                Console.WriteLine("Task Started: " + totalTasks.ToString());
                tasks.Add(task);
            }

            // While any task in a list end create new task and remove the old.
            while (true)
            {
                Task t = await Task.WhenAny(tasks.ToArray());
                Task task = Task.Run(taskToDo);
                Console.WriteLine("Task Started: " + totalTasks.ToString());

                tasks.Remove(t);

                totalTasks += 1;
                tasks.Add(task);
            }
        }

        /// <summary>
        ///   This method await 1-5 seconds.
        /// </summary>
        /// <returns></returns>
        private static async Task taskToDo()
        {
            Random rand = new Random();
            var timeToWait = rand.Next(1, 6);

            await Task.Delay(timeToWait * 1000);
            Console.WriteLine("Task Finished!");
        }
    }
}
